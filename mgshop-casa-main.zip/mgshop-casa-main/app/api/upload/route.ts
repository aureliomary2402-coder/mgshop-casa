import { createAdminClient } from '@/lib/supabase/admin'
import { type NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    if (!file) return NextResponse.json({ error: 'No file provided' }, { status: 400 })

    const supabase = createAdminClient()
    const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg'
    const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`

    const { error } = await supabase.storage
      .from('images')
      .upload(fileName, file, { contentType: file.type, upsert: false })

    if (error) {
      console.error('Upload failed:', error)
      return NextResponse.json({ error: `Upload fallito: ${error.message}` }, { status: 500 })
    }

    // La trasformazione "render/image" di Supabase esiste solo per le
    // immagini: per i video (o altri file non-immagine) va restituito
    // l'URL pubblico "grezzo", altrimenti il file non si carica più.
    const isVideo = file.type.startsWith('video/')
    const { data: urlData } = isVideo
      ? supabase.storage.from('images').getPublicUrl(fileName)
      : supabase.storage.from('images').getPublicUrl(fileName, {
          transform: { width: 2000, height: 2000, resize: 'contain', quality: 90 }
        })

    return NextResponse.json({ url: urlData.publicUrl, isVideo })
  } catch (e: any) {
    console.error('Upload exception:', e)
    return NextResponse.json({ error: `Upload fallito: ${e?.message || 'errore sconosciuto'}` }, { status: 500 })
  }
}
