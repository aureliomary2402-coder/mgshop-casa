"use client"
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, Clock, Tag, ShoppingBag, ShoppingCart, ImageIcon, X, Info } from 'lucide-react'
import { PageHero } from '@/components/shop/page-hero'
import { useCartStore } from '@/lib/cart-store'
import { useProductDetailStore } from '@/lib/product-detail-store'
import { toast } from 'sonner'
import type { Product } from '@/lib/types'
import { Reveal } from '@/components/shop/reveal'
import { AmbientBubbles } from '@/components/shop/ambient-bubbles'
import { buildCustomPromoProduct, isCustomPromoProductId } from '@/lib/promo-custom-product'
import { TornaPrestoStamp } from '@/components/shop/torna-presto-stamp'

interface PromoItem {
  id: string
  product_id: string | null
  name?: string
  image_url?: string | null
  original_price?: number
  sale_price: number
  description?: string
  torna_presto?: boolean
}

interface PromoData {
  is_active: boolean; title: string; subtitle: string; content: string
  image_url: string; badge_text: string; expires_at: string; promo_items: PromoItem[]
}

function Countdown({ expiresAt }: { expiresAt: string }) {
  const [t, setT] = useState({ days:0, hours:0, minutes:0, seconds:0 })
  const [expired, setExpired] = useState(false)
  useEffect(() => {
    const calc = () => { const d = new Date(expiresAt).getTime()-Date.now(); if(d<=0){setExpired(true);return} setT({days:Math.floor(d/86400000),hours:Math.floor((d%86400000)/3600000),minutes:Math.floor((d%3600000)/60000),seconds:Math.floor((d%60000)/1000)}) }
    calc(); const i=setInterval(calc,1000); return ()=>clearInterval(i)
  },[expiresAt])
  if(expired) return <div className="text-center text-slate-400 text-sm">Offerta scaduta</div>
  return (
    <div className="flex items-center justify-center gap-3">
      {[{v:t.days,l:'Giorni'},{v:t.hours,l:'Ore'},{v:t.minutes,l:'Min'},{v:t.seconds,l:'Sec'}].map(({v,l},i)=>(
        <div key={l} className="flex items-center gap-3">
          <div className="text-center">
            <div className="w-14 h-14 rounded-xl flex items-center justify-center font-bold text-2xl text-white" style={{background:'linear-gradient(135deg,#0891b2,#06b6d4)',boxShadow:'0 4px 16px rgba(8,145,178,0.3)'}}>{String(v).padStart(2,'0')}</div>
            <p className="text-xs mt-1" style={{ color: 'rgba(224,247,250,0.65)' }}>{l}</p>
          </div>
          {i<3&&<span className="text-cyan-500 font-bold text-xl mb-4">:</span>}
        </div>
      ))}
    </div>
  )
}

function PromoProductCard({ product, salePrice, onOpenDetail }: { product: Product; salePrice: number; onOpenDetail: () => void }) {
  const addItem = useCartStore(s => s.addItem)
  const [added, setAdded] = useState(false)

  const hasDiscount = salePrice < product.price
  const percentOff = hasDiscount ? Math.round((1 - salePrice / product.price) * 100) : 0

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (product.torna_presto) return
    addItem({ ...product, price: salePrice })
    setAdded(true)
    setTimeout(() => setAdded(false), 1500)
    toast.success(`${product.name} aggiunto!`, { style: { background: '#cffafe', border: '1px solid #0891b2', color: '#155e75' } })
  }

  return (
    <div onClick={onOpenDetail} role="button"
      className="bg-white rounded-2xl overflow-hidden shadow-sm hover:-translate-y-1 transition-all group cursor-pointer"
      style={{ border: '1px solid rgba(8,145,178,0.1)', boxShadow: '0 4px 20px rgba(8,145,178,0.08)' }}>
      <div className="aspect-square overflow-hidden relative" style={{ background: 'linear-gradient(135deg,#f0fbfd,#cffafe)' }}>
        {(product.card_image || product.cover_image)
          ? <img src={product.card_image || product.cover_image || ''} alt={product.name} draggable={false} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 select-none" style={product.torna_presto ? { filter: 'grayscale(1)' } : undefined} />
          : <div className="w-full h-full flex items-center justify-center"><ImageIcon className="w-10 h-10" style={{color:'rgba(8,145,178,0.3)'}}/></div>}
        {product.torna_presto && <TornaPrestoStamp />}
        {hasDiscount && !product.torna_presto && (
          <div className="absolute top-2 left-2 text-white text-xs font-bold px-2 py-1 rounded-lg" style={{ background: '#dc2626' }}>
            -{percentOff}%
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-sm text-slate-800 line-clamp-2 mb-2 group-hover:text-cyan-700 transition-colors">{product.name}</h3>
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            {hasDiscount ? (
              <>
                <span className="text-xs text-slate-400 line-through">€{product.price.toFixed(2)}</span>
                <span className="font-bold text-lg" style={{ color: '#dc2626' }}>€{salePrice.toFixed(2)}</span>
              </>
            ) : (
              <span className="font-bold text-lg" style={{ color: '#0891b2' }}>€{salePrice.toFixed(2)}</span>
            )}
          </div>
          <button onClick={handleAdd}
            disabled={product.torna_presto}
            className="flex items-center gap-1.5 text-white text-xs font-semibold px-4 py-2 rounded-full transition-all active:scale-95 disabled:cursor-not-allowed"
            style={product.torna_presto
              ? { background: '#94a3b8', boxShadow: 'none' }
              : { background: added ? 'linear-gradient(135deg,#16a34a,#22c55e)' : 'linear-gradient(135deg,#0891b2,#06b6d4)', boxShadow: '0 4px 12px rgba(8,145,178,0.3)' }}>
            <ShoppingCart className="w-3.5 h-3.5" />
            {product.torna_presto ? 'Non disponibile' : added ? 'Aggiunto!' : 'Aggiungi'}
          </button>
        </div>
      </div>
    </div>
  )
}

// Scheda con le informazioni del prodotto in promo. Non riusiamo la pagina
// /prodotto/[id] perché i prodotti creati apposta per una promo non
// esistono nel catalogo vero: qui mostriamo le informazioni scritte
// dall'admin direttamente nella promo, senza bisogno di una pagina a parte.
function PromoDetailModal({ product, salePrice, onClose }: { product: Product; salePrice: number; onClose: () => void }) {
  const addItem = useCartStore(s => s.addItem)
  const [added, setAdded] = useState(false)
  const hasDiscount = salePrice < product.price
  const percentOff = hasDiscount ? Math.round((1 - salePrice / product.price) * 100) : 0

  const handleAdd = () => {
    if (product.torna_presto) return
    addItem({ ...product, price: salePrice })
    setAdded(true)
    toast.success(`${product.name} aggiunto!`, { style: { background: '#cffafe', border: '1px solid #0891b2', color: '#155e75' } })
    setTimeout(onClose, 700)
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4" style={{ background: 'rgba(12,43,54,0.5)' }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} className="bg-white w-full sm:max-w-md sm:rounded-3xl rounded-t-3xl overflow-hidden max-h-[90vh] flex flex-col animate-slide-in-right">
        <div className="relative shrink-0" style={{ height: '200px', background: 'linear-gradient(135deg,#f0fbfd,#cffafe)' }}>
          {product.cover_image
            ? <img src={product.cover_image} alt={product.name} className="w-full h-full object-cover" style={product.torna_presto ? { filter: 'grayscale(1)' } : undefined} />
            : <div className="w-full h-full flex items-center justify-center"><ImageIcon className="w-12 h-12" style={{color:'rgba(8,145,178,0.3)'}}/></div>}
          {product.torna_presto && <TornaPrestoStamp size="50%" />}
          <button onClick={onClose} className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center hover:scale-110 transition-transform"><X className="w-4 h-4 text-slate-600"/></button>
          {hasDiscount && !product.torna_presto && <div className="absolute top-3 left-3 text-white text-xs font-bold px-2.5 py-1 rounded-lg" style={{ background: '#dc2626' }}>-{percentOff}%</div>}
        </div>
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          <h2 className="text-xl font-bold" style={{color:'#0c2b36'}}>{product.name}</h2>
          <div className="flex items-baseline gap-2">
            {hasDiscount && <span className="text-sm text-slate-400 line-through">€{product.price.toFixed(2)}</span>}
            <span className="text-2xl font-bold" style={{ color: hasDiscount ? '#dc2626' : '#0891b2' }}>€{salePrice.toFixed(2)}</span>
          </div>
          {product.description && (
            <div className="flex gap-2 p-3 rounded-xl" style={{ background: 'rgba(8,145,178,0.05)' }}>
              <Info className="w-4 h-4 text-cyan-600 shrink-0 mt-0.5" />
              <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-line">{product.description}</p>
            </div>
          )}
          <button onClick={handleAdd}
            disabled={product.torna_presto}
            className="w-full flex items-center justify-center gap-2 text-white font-bold py-3.5 rounded-2xl transition-all active:scale-95 disabled:cursor-not-allowed"
            style={product.torna_presto
              ? { background: '#94a3b8', boxShadow: 'none' }
              : { background: added ? 'linear-gradient(135deg,#16a34a,#22c55e)' : 'linear-gradient(135deg,#0891b2,#06b6d4)', boxShadow: '0 8px 20px rgba(8,145,178,0.3)' }}>
            <ShoppingCart className="w-4 h-4" /> {product.torna_presto ? 'Non disponibile' : added ? 'Aggiunto!' : 'Aggiungi al carrello'}
          </button>
        </div>
      </div>
    </div>
  )
}

export default function PromoPage() {
  const [promo, setPromo] = useState<PromoData|null>(null)
  const [displayItems, setDisplayItems] = useState<{ product: Product; salePrice: number }[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedDetail, setSelectedDetail] = useState<{ product: Product; salePrice: number } | null>(null)
  const cartCount = useCartStore(s => s.getTotalItems)()

  useEffect(()=>{
    fetch('/api/promo', { cache: 'no-store' })
      .then(r=>r.json())
      .then(async d => {
        setPromo(d)
        const promoItems: PromoItem[] = d.promo_items || []
        const shopIds = promoItems.filter(i => i.product_id).map(i => i.product_id as string)
        let shopProducts: Product[] = []
        if (shopIds.length > 0) {
          const allProducts = await fetch('/api/admin/products').then(r=>r.json())
          shopProducts = allProducts.filter((p: Product) => shopIds.includes(p.id))
        }
        const built = promoItems.map(item => {
          if (item.product_id) {
            const p = shopProducts.find(sp => sp.id === item.product_id)
            if (!p) return null
            const withPromoInfo = item.description?.trim() ? { ...p, description: item.description } : p
            return { product: withPromoInfo, salePrice: item.sale_price }
          }
          const custom = buildCustomPromoProduct({
            id: item.id, name: item.name || 'Prodotto', image_url: item.image_url || null,
            price: item.original_price ?? item.sale_price, description: item.description || null,
            torna_presto: item.torna_presto,
          })
          return { product: custom, salePrice: item.sale_price }
        }).filter((x): x is { product: Product; salePrice: number } => !!x)
        setDisplayItems(built)
        setLoading(false)
      })
      .catch(()=>setLoading(false))
  },[])

  if(loading) return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(180deg,#eafbff 0%,#f5fdff 45%,#ffffff 100%)' }}>
      <div className="max-w-4xl mx-auto px-4 py-12 space-y-6">
        <div className="skeleton h-40 rounded-3xl" />
        <div className="skeleton h-10 w-2/3 mx-auto rounded-lg" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="skeleton aspect-square rounded-2xl" />)}
        </div>
      </div>
    </div>
  )

  if(!promo||!promo.is_active) return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: 'linear-gradient(180deg,#eafbff 0%,#f5fdff 45%,#ffffff 100%)' }}>
      <div className="text-center max-w-md">
        <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6" style={{background:'rgba(8,145,178,0.08)',border:'2px dashed rgba(8,145,178,0.2)'}}><ShoppingBag className="w-12 h-12" style={{color:'rgba(8,145,178,0.4)'}}/></div>
        <h1 className="text-2xl font-bold mb-2" style={{color:'#0c2b36'}}>Nessuna promo attiva</h1>
        <p className="text-slate-400 mb-8">Torna presto per le nostre offerte!</p>
        <Link href="/shop" className="inline-flex items-center gap-2 font-bold px-8 py-4 rounded-2xl text-white" style={{background:'linear-gradient(135deg,#0891b2,#06b6d4)'}}><ArrowLeft className="w-4 h-4"/> Vai al negozio</Link>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(180deg,#eafbff 0%,#f5fdff 45%,#ffffff 100%)' }}>
      {/* Hero */}
      <PageHero
        icon={Tag}
        iconColor="#f59e0b"
        badge={promo.badge_text ? { icon: Tag, text: promo.badge_text } : undefined}
        title={promo.title}
        subtitle={promo.subtitle}
        cart={{ count: cartCount, href: '/carrello?promo=1' }}
      >
        {promo.expires_at && (
          <div className="mb-4">
            <div className="flex items-center justify-center gap-2 text-sm mb-3" style={{ color: '#67e8f9' }}><Clock className="w-4 h-4"/> Offerta valida ancora per:</div>
            <Countdown expiresAt={promo.expires_at}/>
          </div>
        )}
      </PageHero>

      {/* Content */}
      <div className="relative overflow-hidden">
        <AmbientBubbles count={16} theme="light" />
        <div className="relative z-10 max-w-5xl mx-auto px-4 py-10 space-y-10">
          {(promo.image_url||promo.content)&&(
            <Reveal className={`grid gap-6 ${promo.image_url&&promo.content?'md:grid-cols-2':''}`}>
              {promo.image_url&&<div className="rounded-2xl overflow-hidden aspect-video" style={{boxShadow:'0 16px 40px rgba(8,145,178,0.12)'}}><img src={promo.image_url} alt="Promo" className="w-full h-full object-cover"/></div>}
              {promo.content&&<div className="flex items-center"><div className="glass-card rounded-2xl p-6 w-full"><p className="text-slate-600 leading-relaxed whitespace-pre-line">{promo.content}</p></div></div>}
            </Reveal>
          )}

          {/* Prodotti in promo */}
          {displayItems.length > 0 && (
            <Reveal delay={100}>
              <h2 className="text-2xl font-bold mb-6" style={{color:'#0c2b36'}}>Prodotti in promozione</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 stagger-children">
                {displayItems.map(({ product, salePrice }) => (
                  <PromoProductCard key={product.id} product={product} salePrice={salePrice}
                    onOpenDetail={() => {
                      if (isCustomPromoProductId(product.id)) setSelectedDetail({ product, salePrice })
                      else useProductDetailStore.getState().open(product.id)
                    }} />
                ))}
              </div>
              {/* Sticky cart button */}
              {cartCount > 0 && (
                <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-scale-in">
                  <Link href="/carrello?promo=1"
                    className="flex items-center gap-3 px-8 py-4 rounded-2xl text-white font-bold shadow-2xl transition-all hover:scale-105 neon-glow"
                    style={{ background: 'linear-gradient(135deg,#0891b2,#06b6d4)' }}>
                    <ShoppingBag className="w-5 h-5"/>
                    Vai al carrello ({cartCount})
                  </Link>
                </div>
              )}
            </Reveal>
          )}

          <Reveal delay={150} className="text-center py-6">
            <Link href="/shop" className="inline-flex items-center gap-2 font-bold px-10 py-4 rounded-2xl text-white" style={{background:'linear-gradient(135deg,#0891b2,#06b6d4)',boxShadow:'0 12px 32px rgba(8,145,178,0.35)'}}>
              <ShoppingBag className="w-5 h-5"/> Vai al negozio completo
            </Link>
          </Reveal>
        </div>
      </div>
      {selectedDetail && (
        <PromoDetailModal product={selectedDetail.product} salePrice={selectedDetail.salePrice} onClose={() => setSelectedDetail(null)} />
      )}
    </div>
  )
}
