"use client"

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, Minus, Plus, Trash2, ShoppingBag, ImageIcon, CheckCircle, ShoppingCart, Tag, X, Gift, MapPin, Truck, Store, MessageCircle } from 'lucide-react'
import { useCartStore } from '@/lib/cart-store'
import { LOTTERY_TICKET_PRODUCT_ID, createLotteryTicketProduct } from '@/lib/lottery-ticket-product'
import { LoyaltyBanner } from './loyalty-banner'
import { CodBanner } from './cod-banner'
import { RecentlyViewed } from './recently-viewed'
import { PageHero } from './page-hero'
import { subscribeToPush } from '@/lib/push-subscribe'

export function CartContent({ scope = 'shop' }: { scope?: string }) {
  const [mounted, setMounted] = useState(false)
  const [phone, setPhone] = useState('')
  const [wantsDelivery, setWantsDelivery] = useState(false)
  const [address, setAddress] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState('')
  const [couponCode, setCouponCode] = useState('')
  const [couponInput, setCouponInput] = useState('')
  const [couponData, setCouponData] = useState<{ discount_percent: number; discount_fixed: number; code: string; scope: string } | null>(null)
  const [couponError, setCouponError] = useState('')
  const [couponLoading, setCouponLoading] = useState(false)
  const [promoProductIds, setPromoProductIds] = useState<string[]>([])
  const [lotteryActive, setLotteryActive] = useState(false)
  const [lotteryPrizeLabel, setLotteryPrizeLabel] = useState('')
  const [ticketPrice, setTicketPrice] = useState(1)
  const [ticketQtyToAdd, setTicketQtyToAdd] = useState(1)
  const [ticketNumbers, setTicketNumbers] = useState<number[]>([])
  const [participantsCount, setParticipantsCount] = useState(0)
  const [takenNumbers, setTakenNumbers] = useState<number[]>([])
  const [showNumberPicker, setShowNumberPicker] = useState(false)
  const [chosenNumbers, setChosenNumbers] = useState<number[]>([])

  const items = useCartStore(s => s.items)
  const addItem = useCartStore(s => s.addItem)
  const updateQuantity = useCartStore(s => s.updateQuantity)
  const removeItem = useCartStore(s => s.removeItem)
  const clearCart = useCartStore(s => s.clearCart)
  const getTotalPrice = useCartStore(s => s.getTotalPrice)

  const ticketQtyInCart = items.find(i => i.product.id === LOTTERY_TICKET_PRODUCT_ID)?.quantity || 0

  // Se il cliente riduce la quantità di biglietti (o li rimuove), teniamo
  // al massimo tanti numeri scelti quanti sono i biglietti rimasti nel carrello.
  useEffect(() => {
    if (chosenNumbers.length > ticketQtyInCart) setChosenNumbers(prev => prev.slice(0, ticketQtyInCart))
    if (ticketQtyInCart === 0) setShowNumberPicker(false)
  }, [ticketQtyInCart]) // eslint-disable-line react-hooks/exhaustive-deps

  const toggleChosenNumber = (n: number) => {
    setChosenNumbers(prev => {
      if (prev.includes(n)) return prev.filter(x => x !== n)
      if (prev.length >= ticketQtyInCart) return prev
      return [...prev, n].sort((a, b) => a - b)
    })
  }

  const addLotteryTickets = (qty: number) => {
    const existing = items.find(i => i.product.id === LOTTERY_TICKET_PRODUCT_ID)
    if (existing) updateQuantity(LOTTERY_TICKET_PRODUCT_ID, existing.quantity + qty)
    else {
      addItem(createLotteryTicketProduct(ticketPrice))
      if (qty > 1) updateQuantity(LOTTERY_TICKET_PRODUCT_ID, qty)
    }
    setTicketQtyToAdd(1)
  }

  // Se il biglietto era già nel carrello (salvato nel browser da prima) con
  // un prezzo diverso da quello attuale impostato dall'admin, lo riallineiamo
  // così il totale mostrato e quello inviato al checkout sono sempre corretti.
  useEffect(() => {
    if (!mounted) return
    const existing = items.find(i => i.product.id === LOTTERY_TICKET_PRODUCT_ID)
    if (existing && existing.product.price !== ticketPrice) {
      const qtyInCart = existing.quantity
      removeItem(LOTTERY_TICKET_PRODUCT_ID)
      addItem(createLotteryTicketProduct(ticketPrice))
      if (qtyInCart > 1) updateQuantity(LOTTERY_TICKET_PRODUCT_ID, qtyInCart)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mounted, ticketPrice])

  useEffect(() => {
    setMounted(true)
    // Carica quali prodotti fanno parte della promo attiva, per calcolare lo sconto solo su quelli quando serve
    fetch('/api/promo', { cache: 'no-store' })
      .then(r => r.json())
      .then(d => setPromoProductIds(d?.is_active ? (d.featured_product_ids || []) : []))
      .catch(() => setPromoProductIds([]))
    fetch('/api/lottery', { cache: 'no-store' })
      .then(r => r.json())
      .then(d => {
        setLotteryActive(d?.is_active === true)
        setLotteryPrizeLabel(d?.prize_label || '')
        setParticipantsCount(d?.participants_count || 0)
        setTakenNumbers(d?.taken_numbers || [])
        setTicketPrice(d?.ticket_price ?? 1)
      })
      .catch(() => {})
  }, [])

  const subtotal = mounted ? getTotalPrice() : 0
  // Se il coupon vale solo per la promo, lo sconto si calcola solo sui prodotti in promo presenti nel carrello
  const promoSubtotal = items.reduce((sum, i) => promoProductIds.includes(i.product.id) ? sum + i.product.price * i.quantity : sum, 0)
  const discountBase = couponData?.scope === 'promo' ? promoSubtotal : subtotal
  const discountAmount = couponData
    ? couponData.discount_percent > 0
      ? discountBase * couponData.discount_percent / 100
      : Math.min(couponData.discount_fixed, discountBase)
    : 0
  const total = Math.max(0, subtotal - discountAmount)

  const handleApplyCoupon = async () => {
    if (!couponInput.trim()) return
    setCouponLoading(true); setCouponError('')
    const res = await fetch('/api/coupons', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: couponInput, scope }) })
    const data = await res.json()
    if (res.ok) { setCouponData(data); setCouponCode(couponInput); setCouponInput('') }
    else setCouponError(data.error || 'Coupon non valido')
    setCouponLoading(false)
  }

  const removeCoupon = () => { setCouponData(null); setCouponCode(''); setCouponError('') }

  const handlePhoneChange = (value: string) => {
    setPhone(value)
    try { sessionStorage.setItem('mgshop-checkout-phone', value) } catch {}
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError('')
    if (!phone.trim()) { setError('Inserisci il tuo numero di telefono'); return }
    if (wantsDelivery && !address.trim()) { setError('Inserisci l\'indirizzo di consegna'); return }
    setSubmitting(true)
    try {
      const res = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone_number: phone, items, total, coupon_code: couponCode || null, ticket_number_choices: chosenNumbers, delivery_method: wantsDelivery ? 'consegna' : 'ritiro', delivery_address: wantsDelivery ? address : null }) })
      const data = await res.json().catch(() => null)
      if (!res.ok) {
        // Uno o più numeri scelti sono stati presi da un altro cliente nel
        // frattempo: li togliamo dalla selezione e aggiorniamo la lista dei
        // numeri occupati, così il cliente può subito sceglierne altri.
        if (data?.unavailable_numbers?.length) {
          setChosenNumbers(prev => prev.filter(n => !data.unavailable_numbers.includes(n)))
          setTakenNumbers(prev => Array.from(new Set([...prev, ...data.unavailable_numbers])))
          setShowNumberPicker(true)
        }
        // Il prezzo del biglietto era cambiato rispetto a quello nel
        // carrello: lo riallineiamo subito, così basta premere di nuovo
        // "Invia ordine" e stavolta passa al prezzo giusto.
        if (data?.ticket_price_changed && typeof data.ticket_price === 'number') {
          setTicketPrice(data.ticket_price)
        }
        setError(data?.error || 'Si è verificato un errore. Riprova.'); setSubmitting(false); return
      }
      if (data.ticket_numbers?.length) setTicketNumbers(data.ticket_numbers)
      setChosenNumbers([])
      setWantsDelivery(false); setAddress('')
      try {
        const sessionId = sessionStorage.getItem('mgshop-session-id')
        sessionStorage.removeItem('mgshop-checkout-phone')
        if (sessionId) fetch('/api/analytics/cart-abandon', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId }) }).catch(() => {})
      } catch {}
      clearCart(); setSubmitted(true)
      subscribeToPush(phone).catch(() => {})
    } catch { setError('Si è verificato un errore. Riprova.') }
    finally { setSubmitting(false) }
  }

  if (!mounted) return (
    <>
      <PageHero icon={ShoppingBag} iconColor="#22d3ee" title="Carrello" subtitle="Rivedi i prodotti scelti e completa l'ordine." />
      <div className="max-w-4xl mx-auto px-4 py-12 grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="flex gap-3 p-3 rounded-2xl bg-white border border-slate-100">
              <div className="skeleton w-20 h-20 rounded-xl shrink-0" />
              <div className="flex-1 space-y-2 py-1">
                <div className="skeleton h-4 w-3/4 rounded-full" />
                <div className="skeleton h-4 w-1/3 rounded-full" />
              </div>
            </div>
          ))}
        </div>
        <div className="skeleton rounded-2xl h-64" />
      </div>
    </>
  )

  if (submitted) return (
    <div className="max-w-md mx-auto px-4 py-20 text-center animate-scale-in">
      <div className="relative w-24 h-24 mx-auto mb-6">
        {['#0891b2','#06b6d4','#22d3ee','#16a34a','#ef4444','#3b82f6'].map((color, i) => (
          <div key={i} className="confetti-piece"
            style={{
              left: `${50 + (i % 2 === 0 ? -1 : 1) * (10 + i * 6)}%`,
              top: '10%',
              width: 6, height: 6,
              background: color,
              borderRadius: i % 3 === 0 ? '50%' : '2px',
              animationDelay: `${i * 40}ms`,
            }} />
        ))}
        <div className="w-24 h-24 rounded-full flex items-center justify-center animate-check-pop" style={{background:'linear-gradient(135deg,#0891b2,#06b6d4)',boxShadow:'0 20px 40px rgba(8,145,178,0.3)'}}>
          <CheckCircle className="w-12 h-12 text-white"/>
        </div>
      </div>
      <h2 className="text-3xl font-bold mb-3" style={{color:'#0c2b36'}}>Ordine inviato!</h2>
      <p className="text-slate-500 mb-2">Ti contatteremo presto su WhatsApp per confermare.</p>
      {ticketNumbers.length > 0 && (
        <div className="mb-2">
          <p className="text-sm font-bold text-slate-700 mb-2">I tuoi numeri per la lotteria:</p>
          <div className="flex flex-wrap justify-center gap-2">
            {ticketNumbers.map(n => (
              <span key={n} className="px-3 py-1.5 rounded-xl font-bold text-white" style={{ background: 'linear-gradient(135deg,#f59e0b,#ea580c)' }}>#{n}</span>
            ))}
          </div>
        </div>
      )}
      <p className="text-sm text-cyan-700 font-medium mb-8">🎁 Riceverai i tuoi punti fedeltà via WhatsApp!</p>
      <Link href="/shop" className="inline-flex items-center gap-2 font-bold px-8 py-4 rounded-2xl text-white btn-press" style={{background:'linear-gradient(135deg,#0891b2,#06b6d4)'}}>
        <ShoppingBag className="w-5 h-5"/> Continua a fare shopping
      </Link>
    </div>
  )

  if (items.length === 0) return (
    <>
      <PageHero icon={ShoppingBag} iconColor="#22d3ee" title="Carrello" subtitle="Rivedi i prodotti scelti e completa l'ordine." />
      <div className="max-w-md mx-auto px-4 py-20 text-center animate-scale-in">
        <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6" style={{background:'rgba(8,145,178,0.08)',border:'2px dashed rgba(8,145,178,0.2)'}}>
          <ShoppingCart className="w-12 h-12" style={{color:'rgba(8,145,178,0.4)'}}/>
        </div>
        <h2 className="text-2xl font-bold mb-2" style={{color:'#0c2b36'}}>Il carrello è vuoto</h2>
        <p className="text-slate-400 mb-8">Aggiungi qualche prodotto per iniziare.</p>
        <Link href="/shop" className="inline-flex items-center gap-2 font-bold px-8 py-4 rounded-2xl text-white btn-press" style={{background:'linear-gradient(135deg,#0891b2,#06b6d4)'}}>Vai ai prodotti</Link>
        <div className="mt-10 text-left">
          <RecentlyViewed />
        </div>
      </div>
    </>
  )

  return (
    <>
      <PageHero icon={ShoppingBag} iconColor="#22d3ee" title="Carrello" subtitle={`${items.length} ${items.length===1?'articolo':'articoli'} pronti per il checkout.`} />
      <div className="w-full overflow-x-hidden max-w-5xl mx-auto px-4 py-6 sm:py-8">
      <Link href="/shop" className="inline-flex items-center gap-2 text-sm font-medium mb-4 sm:mb-6 group transition-all hover:gap-3" style={{color:'#155e75'}}>
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform"/> Continua lo shopping
      </Link>
      <div className="grid md:grid-cols-3 gap-5 md:gap-6">
        <div className="md:col-span-2 space-y-3 min-w-0">
          {items.map(({product,quantity,lineId,unitPrice},i) => {
            const rowId = lineId || product.id
            const price = unitPrice ?? product.price
            return (
            <div key={rowId} className="flex gap-3 sm:gap-4 rounded-2xl p-3 sm:p-4 animate-fade-in-up"
              style={{animationDelay:`${i*50}ms`,animationFillMode:'both',background:'white',border:'1px solid rgba(8,145,178,0.08)',boxShadow:'0 2px 8px rgba(0,0,0,0.04)'}}>
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden shrink-0" style={{background:'linear-gradient(135deg,#f0fbfd,#cffafe)'}}>
                {product.cover_image ? <img src={product.cover_image} alt={product.name} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center"><ImageIcon className="w-8 h-8" style={{color:'rgba(8,145,178,0.3)'}}/></div>}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm sm:text-base font-semibold truncate mb-1" style={{color:'#0c2b36'}}>{product.name}</p>
                <p className="font-bold" style={{color:'#0891b2'}}>€{price.toFixed(2)}</p>
                <div className="flex items-center gap-2 mt-2">
                  <button onClick={() => updateQuantity(rowId,quantity-1)} className="w-7 h-7 rounded-full flex items-center justify-center transition-all hover:scale-110 btn-press shrink-0" style={{border:'1px solid rgba(8,145,178,0.2)',background:'rgba(8,145,178,0.04)'}}><Minus className="w-3 h-3" style={{color:'#155e75'}}/></button>
                  <span className="w-6 text-center text-sm font-bold shrink-0" style={{color:'#0c2b36'}}>{quantity}</span>
                  <button onClick={() => updateQuantity(rowId,quantity+1)} className="w-7 h-7 rounded-full flex items-center justify-center transition-all hover:scale-110 btn-press shrink-0" style={{border:'1px solid rgba(8,145,178,0.2)',background:'rgba(8,145,178,0.04)'}}><Plus className="w-3 h-3" style={{color:'#155e75'}}/></button>
                  <button onClick={() => removeItem(rowId)} className="ml-auto w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:scale-110 btn-press shrink-0" style={{background:'rgba(239,68,68,0.06)',border:'1px solid rgba(239,68,68,0.1)'}}><Trash2 className="w-4 h-4 text-red-400"/></button>
                </div>
              </div>
            </div>
            )
          })}
          {/* Banner fedeltà compact nel carrello */}
          <LoyaltyBanner compact={true} />
        </div>

        <div className="rounded-2xl p-4 sm:p-5 h-fit md:sticky md:top-20 animate-slide-in-right space-y-4 min-w-0 glass-card">
          <h2 className="font-bold" style={{color:'#0c2b36'}}>Riepilogo ordine</h2>
          <div className="space-y-2">
            {items.map(({product,quantity,lineId,unitPrice}) => (
              <div key={lineId || product.id} className="flex justify-between text-sm text-slate-500">
                <span className="truncate mr-2">{product.name} ×{quantity}</span>
                <span className="shrink-0">€{((unitPrice ?? product.price)*quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            {!couponData ? (
              <>
                <div className="flex flex-wrap gap-2">
                  <div className="relative flex-1 min-w-[140px]">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-400"/>
                    <input value={couponInput} onChange={e => setCouponInput(e.target.value.toUpperCase())} onKeyDown={e => e.key==='Enter'&&handleApplyCoupon()} placeholder="Codice coupon"
                      className="w-full h-10 pl-9 pr-3 rounded-xl text-base font-mono outline-none" style={{background:'rgba(8,145,178,0.05)',border:'1px solid rgba(8,145,178,0.15)',color:'#0c2b36'}}/>
                  </div>
                  <button onClick={handleApplyCoupon} disabled={couponLoading||!couponInput.trim()} className="shrink-0 px-3 py-2 rounded-xl text-sm font-medium text-white disabled:opacity-50 transition-all hover:scale-105 btn-press" style={{background:'linear-gradient(135deg,#0891b2,#06b6d4)'}}>
                    {couponLoading?'...':'Applica'}
                  </button>
                </div>
                {couponError && <p className="text-red-500 text-xs">{couponError}</p>}
              </>
            ) : (
              <div className="flex items-center justify-between p-3 rounded-xl" style={{background:'rgba(8,145,178,0.06)',border:'1px solid rgba(8,145,178,0.2)'}}>
                <div>
                  <p className="text-sm font-bold text-cyan-700">{couponData.code}</p>
                  <p className="text-xs text-slate-500">{couponData.discount_percent>0?`-${couponData.discount_percent}%`:`-€${couponData.discount_fixed}`}{couponData.scope==='promo' ? ' (solo prodotti in promo)' : ' (tutto il carrello)'}</p>
                  {couponData.scope==='promo' && promoSubtotal===0 && <p className="text-xs text-red-500 mt-1">Nessun prodotto in promo nel carrello: sconto non applicato</p>}
                </div>
                <button onClick={removeCoupon} className="p-1 hover:bg-cyan-100 rounded-lg"><X className="w-4 h-4 text-cyan-600"/></button>
              </div>
            )}
          </div>
          {lotteryActive && (
            <div className="p-3 rounded-xl" style={{ background: ticketQtyInCart > 0 ? 'rgba(8,145,178,0.08)' : 'rgba(8,145,178,0.03)', border: '1px solid rgba(8,145,178,0.15)' }}>
              <span className="text-sm font-bold flex items-center gap-1.5" style={{ color: '#0c2b36' }}><Gift className="w-4 h-4 text-cyan-600" /> Partecipa alla lotteria</span>
              <span className="text-xs text-slate-400 block mt-0.5 mb-2.5">{lotteryPrizeLabel ? `In palio: ${lotteryPrizeLabel}` : 'Ricevi un numero per l\'estrazione'} — €{ticketPrice.toFixed(2)} a biglietto, puoi prenderne più di uno.</span>

              {ticketQtyInCart > 0 ? (
                <div className="space-y-2.5">
                  <div className="flex items-center gap-2">
                    <button type="button" onClick={() => updateQuantity(LOTTERY_TICKET_PRODUCT_ID, ticketQtyInCart - 1)} className="w-7 h-7 rounded-full flex items-center justify-center bg-white" style={{ border: '1px solid rgba(8,145,178,0.2)' }}><Minus className="w-3 h-3 text-cyan-700" /></button>
                    <span className="w-6 text-center text-sm font-bold text-cyan-700">{ticketQtyInCart}</span>
                    <button type="button" onClick={() => updateQuantity(LOTTERY_TICKET_PRODUCT_ID, ticketQtyInCart + 1)} className="w-7 h-7 rounded-full flex items-center justify-center bg-white" style={{ border: '1px solid rgba(8,145,178,0.2)' }}><Plus className="w-3 h-3 text-cyan-700" /></button>
                    <span className="text-xs text-slate-500 ml-1">bigliett{ticketQtyInCart > 1 ? 'i' : 'o'} nel carrello</span>
                  </div>

                  {participantsCount > 0 && (
                    <button type="button" onClick={() => setShowNumberPicker(v => !v)}
                      className="text-xs font-semibold text-cyan-700 underline underline-offset-2">
                      {showNumberPicker ? 'Nascondi la scelta dei numeri' : chosenNumbers.length > 0 ? `Numeri scelti: ${chosenNumbers.join(', ')} — modifica` : 'Vuoi scegliere tu i numeri? (facoltativo)'}
                    </button>
                  )}

                  {showNumberPicker && participantsCount > 0 && (
                    <div className="p-2.5 rounded-lg bg-white" style={{ border: '1px solid rgba(8,145,178,0.15)' }}>
                      <p className="text-xs text-slate-500 mb-2">
                        Scegli fino a {ticketQtyInCart} numer{ticketQtyInCart > 1 ? 'i' : 'o'} ({chosenNumbers.length}/{ticketQtyInCart} scelt{chosenNumbers.length === 1 ? 'o' : 'i'}). I biglietti senza numero scelto vengono assegnati automaticamente.
                      </p>
                      <div className="grid grid-cols-6 sm:grid-cols-8 gap-1 max-h-40 overflow-y-auto">
                        {Array.from({ length: participantsCount }, (_, i) => i + 1).map(n => {
                          const isTaken = takenNumbers.includes(n)
                          const isChosen = chosenNumbers.includes(n)
                          return (
                            <button key={n} type="button" disabled={isTaken}
                              onClick={() => toggleChosenNumber(n)}
                              className="h-7 rounded-md text-[11px] font-bold flex items-center justify-center transition-all disabled:cursor-not-allowed"
                              style={isTaken
                                ? { background: 'rgba(148,163,184,0.15)', color: 'rgba(100,116,139,0.5)', textDecoration: 'line-through' }
                                : isChosen
                                  ? { background: 'linear-gradient(135deg,#0891b2,#06b6d4)', color: 'white' }
                                  : { background: 'rgba(8,145,178,0.05)', border: '1px solid rgba(8,145,178,0.15)', color: '#0c2b36' }}>
                              {n}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 bg-white rounded-lg border border-cyan-200 px-1">
                    <button type="button" onClick={() => setTicketQtyToAdd(q => Math.max(1, q - 1))} className="w-7 h-7 flex items-center justify-center text-cyan-700"><Minus className="w-3 h-3" /></button>
                    <span className="w-5 text-center text-sm font-bold text-slate-800">{ticketQtyToAdd}</span>
                    <button type="button" onClick={() => setTicketQtyToAdd(q => Math.min(20, q + 1))} className="w-7 h-7 flex items-center justify-center text-cyan-700"><Plus className="w-3 h-3" /></button>
                  </div>
                  <button type="button" onClick={() => addLotteryTickets(ticketQtyToAdd)}
                    className="text-xs font-bold text-white px-3 py-2 rounded-lg transition-transform hover:scale-105 active:scale-95"
                    style={{ background: 'linear-gradient(135deg,#0891b2,#06b6d4)' }}>
                    Aggiungi (€{(ticketQtyToAdd * ticketPrice).toFixed(2)})
                  </button>
                </div>
              )}
            </div>
          )}
          <div className="border-t border-cyan-100 pt-3 space-y-1.5">
            <div className="flex justify-between text-sm text-slate-500"><span>Subtotale</span><span>€{subtotal.toFixed(2)}</span></div>
            {couponData&&discountAmount>0&&<div className="flex justify-between text-sm text-green-600 font-medium"><span>Sconto coupon</span><span>-€{discountAmount.toFixed(2)}</span></div>}
            <div className="flex justify-between font-bold pt-1"><span style={{color:'#0c2b36'}}>Totale</span><span className="text-xl" style={{color:'#0891b2'}}>€{total.toFixed(2)}</span></div>
          </div>
          <CodBanner />
          <Link href="/consegne" className="flex items-center justify-center gap-1.5 text-xs text-cyan-700/70 hover:text-cyan-700 transition-colors underline underline-offset-2">
            <MapPin className="w-3.5 h-3.5" /> Vedi le zone di consegna e i relativi costi
          </Link>
          {/* Banner: spiega come funziona il contatto dopo l'ordine */}
          <div className="flex items-start gap-3 p-3 rounded-xl" style={{ background: 'rgba(37,211,102,0.08)', border: '1px solid rgba(37,211,102,0.2)' }}>
            <MessageCircle className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong className="text-green-700">Come funziona:</strong> dopo aver inviato l&apos;ordine con il tuo numero, ti contatteremo su WhatsApp per organizzare {' '}
              {wantsDelivery ? 'la consegna a domicilio' : 'il ritiro in negozio'} in base a quello che hai scelto qui sotto.
            </p>
          </div>

          <div className="space-y-2.5">
            <label className="flex items-center gap-2.5 p-3 rounded-xl cursor-pointer select-none" style={{ background: wantsDelivery ? 'rgba(8,145,178,0.06)' : 'rgba(8,145,178,0.02)', border: '1px solid rgba(8,145,178,0.15)' }}>
              <input type="checkbox" checked={wantsDelivery} onChange={e => setWantsDelivery(e.target.checked)}
                className="w-4.5 h-4.5 rounded accent-cyan-600 shrink-0" style={{ width: 18, height: 18 }} />
              <span className="flex items-center gap-2 text-sm font-medium" style={{ color: '#0c2b36' }}>
                {wantsDelivery ? <Truck className="w-4 h-4 text-cyan-600" /> : <Store className="w-4 h-4 text-cyan-600" />}
                Voglio la consegna a domicilio
              </span>
            </label>
            <p className="text-xs text-slate-400 -mt-1 ml-1">
              {wantsDelivery ? 'Inserisci l\'indirizzo dove vuoi ricevere l\'ordine.' : 'Non spuntata: verrai a ritirare l\'ordine in negozio.'}
            </p>

            {wantsDelivery && (
              <input type="text" placeholder="Indirizzo di consegna (via, civico, città)" value={address} onChange={e => setAddress(e.target.value)}
                className="w-full h-11 px-4 rounded-xl text-base outline-none" style={{ background: 'rgba(8,145,178,0.05)', border: '1px solid rgba(8,145,178,0.15)', color: '#0c2b36' }} />
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <input type="tel" placeholder="Numero di telefono" value={phone} onChange={e=>handlePhoneChange(e.target.value)}
              className="w-full h-11 px-4 rounded-xl text-base outline-none" style={{background:'rgba(8,145,178,0.05)',border:'1px solid rgba(8,145,178,0.15)',color:'#0c2b36'}}/>
            {error&&<p className="text-red-500 text-xs">{error}</p>}
            <button type="submit" disabled={submitting} className="w-full py-3.5 rounded-xl font-bold text-white transition-all hover:scale-[1.02] btn-press disabled:opacity-60" style={{background:'linear-gradient(135deg,#0891b2,#06b6d4)',boxShadow:'0 8px 20px rgba(8,145,178,0.3)'}}>
              {submitting?'Invio in corso...':'Invia ordine'}
            </button>
          </form>
          <p className="text-xs text-center text-slate-400">Ti contatteremo su WhatsApp per confermare</p>
        </div>
      </div>
      </div>
    </>
  )
}
